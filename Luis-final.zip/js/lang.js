$(function() {
  var lang = localStorage.getItem('lang');
  if (!lang) {
    localStorage.setItem('lang', 'pt')
    //alert('local storage was set');
  }
  if (lang == 'pt') {
    $('[lang="en"]').hide();
  } else {
    $('[lang="pt"]').hide();
  }
})

function changeLang() {
  var lang = localStorage.getItem('lang');
  //alert('Language is: '+lang);
  if (lang) {
    //alert('First Else');
    if (lang === 'pt') {
      //alert('Second Else');
      localStorage.setItem('lang', 'en')
      $('[lang="pt"]').hide();
      $('[lang="en"]').show();
    }else {
      localStorage.setItem('lang', 'pt')
      $('[lang="en"]').hide();
      $('[lang="pt"]').show();
    }
  }
}
