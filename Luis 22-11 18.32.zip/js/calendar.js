$(document).ready(function() {
  $('#time').timepicker({
    'timeFormat': 'HH:mm:ss'
  });

  $("#date").datepicker();
  $("#dateEnd").datepicker();
  $("#date").datepicker("option", "dateFormat", "yy-mm-dd");
  $("#dateEnd").datepicker("option", "dateFormat", "yy-mm-dd");
});



$(function() {




  var check = localStorage.getItem('calendar');
  if (check === null) {
    alert('(Debug)Calendar is: ' + check);
    var events = [{
      'title': 'Test Event 1',
      'start': '2018-11-01'
    }]
    alert('(Debug)Events list created: ' + events);
    localStorage.setItem('calendar', JSON.stringify(events));
    var insert = localStorage.getItem('calendar');
    alert('(Debug)localStorage is set: ' + insert);
    var insert = $.parseJSON(localStorage.getItem('calendar'))
    $('#calendar').fullCalendar({
      header: {
        left: '',
        center: 'title'
      },
      eventLimit: true,
      events: insert
    })
  }

  var insert = $.parseJSON(localStorage.getItem('calendar'))
  $('#calendar').fullCalendar({
    header: {
      left: '',
      center: 'title'
    },
    eventLimit: true,
    events: insert
  })



})

function deleteCookies() {
  localStorage.removeItem('calendar');
  alert('(Debug)Calendar Events erased');
  location.reload()
}

function addEvent(x, y) {
  var newEvent = {
    id: 1,
    title: x,
    start: y
  }
  $('#calendar').fullCalendar('renderEvent', newEvent, true);
  var insert = $.parseJSON(localStorage.getItem('calendar'));
  insert.push({
    'title': x,
    'start': y,
    'allDay': false
  })
  localStorage.setItem('calendar', JSON.stringify(insert));

}

function addEventEnd(x, y, z) {
  var newEvent = {
    id: 1,
    title: x,
    start: y,
    end: z
  }
  $('#calendar').fullCalendar('renderEvent', newEvent, true);
  var insert = $.parseJSON(localStorage.getItem('calendar'));
  insert.push({
    'title': x,
    'start': y,
    'end': z,
    'allDay': false
  })
  localStorage.setItem('calendar', JSON.stringify(insert));
}

function addEvent() {

  var time = document.getElementById('time').value;
  var startDate = document.getElementById('date').value;
  var endDate = document.getElementById('dateEnd').value;
  var title = document.getElementById('title').value;
  alert(time+startDate+endDate+title);

  if ((startDate.match(/^(\d{4})\-(\d{2})\-(\d{2})$/)) === null || (endDate.match(/^(\d{4})\-(\d{2})\-(\d{2})$/)) === null ) {
    alert('SET DATE');
  } else if (time === "") {
    alert('SET TIME');
  } else if (title === "") {
    alert('SET TITLE');
  } else {
    var startDate = startDate + 'T' + time;
    addEventEnd(title, startDate, endDate)
  }

  // if the time was set
  /*if (time != '') {
    alert("Time is a :"+time+":")
    // and the end date was set
    alert(endDate === "");
    alert(":"+endDate+":");
    if (!(endDate === "")) {
      var startDate = startDate + 'T' + time;
      addEventEnd(title, startDate, endDate);
      alert('(Debug)Event 1 created with'+startDate+endDate)

    }
    // and the end date was not set
    else {
      var startDate = startDate + 'T' + time;
      addEvent(title, startDate);
      alert('(Debug)Event 2 created with'+startDate)
    }

  } else {
    if (!(endDate === "")) {
      addEventEnd(title, startDate, endDate);
      alert('(Debug)Event 3 created with'+startDate+endDate)

    }
    // and the end date was not set
    else {
      addEvent(title, startDate);
      alert('(Debug)Event 4 created with'+startDate)
    }
  }*/

}
